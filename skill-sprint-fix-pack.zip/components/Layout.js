import Link from 'next/link'
export default function Layout({children, active=''}){
  return (<div>
    <header>
      <div className="container" style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'16px 0'}}>
        <div style={{display:'flex',gap:10,alignItems:'center'}}>
          <div style={{width:36,height:36,background:'#ff7a1a',borderRadius:8,display:'grid',placeItems:'center',color:'#fff',fontWeight:700}}>SS</div>
          <div><b>Skill Sprint</b><div className="hint">Your daily workout for business growth</div></div>
        </div>
        <nav style={{display:'flex',gap:12}}>
          <Link className={active==='home'?'hint':''} href="/">Home</Link>
          <Link className={active==='onboarding'?'hint':''} href="/onboarding">Skill Test</Link>
          <Link className={active==='sprint'?'hint':''} href="/sprint">Today&apos;s Sprint</Link>
          <Link className={active==='dashboard'?'hint':''} href="/dashboard">Dashboard</Link>
        </nav>
      </div>
    </header>
    <main className="container" style={{padding:'24px 0'}}>{children}</main>
    <footer><div className="container" style={{padding:'16px 0'}}>© {new Date().getFullYear()} Skill Sprint</div></footer>
  </div>)
}
