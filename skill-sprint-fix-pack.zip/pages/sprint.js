import { useEffect, useState } from 'react'
import Layout from '../components/Layout'
import { storage } from '../lib/storage'

export default function Sprint(){
  const [loading,setLoading]=useState(false)
  const [error,setError]=useState('')
  const [day,setDay]=useState(null)
  const [tips,setTips]=useState([])
  const [reflection,setReflection]=useState('')
  const [rating,setRating]=useState(0)

  const profile = storage.get('ss_profile')
  const history = storage.get('ss_history', [])

  async function load(){
    if(!profile){ setError('Please complete the skill test first.'); return }
    setLoading(true); setError('')
    try{
      const res = await fetch('/api/generate-sprint', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ profile, history }) })
      const data = await res.json()
      setDay(data.day); setTips(data.tips||[])
    }catch(e){ console.error(e); setError('Could not load today\'s sprint.') }
    finally{ setLoading(false) }
  }

  useEffect(()=>{ load() },[])

  function complete(){
    const entry = { date: new Date().toISOString(), title: day?.title||'Sprint', reflection, rating }
    const next = [...history, entry]
    storage.set('ss_history', next)
    alert('Progress saved!')
  }

  return (<Layout active="sprint">
    <h1>Today&apos;s Sprint</h1>
    {error && <div className="card"><b>Note:</b> <span className="hint">{error}</span></div>}
    {loading && <div className="card">Loading…</div>}
    {day && (<div className="grid" style={{gridTemplateColumns:'2fr 1fr'}}>
      <div className="card">
        <div className="hint">Sprint</div>
        <h3>{day.title}</h3>
        <p className="hint">{day.knowledge}</p>
        <div><b>Task</b><p>{day.task}</p></div>
        <div style={{marginTop:12}}>
          <b>Reflection</b>
          <p className="hint">{day.reflection}</p>
          <textarea rows="3" style={{width:'100%'}} value={reflection} onChange={e=>setReflection(e.target.value)} />
          <div style={{display:'flex',gap:8,marginTop:8}}>
            <span className="hint">How useful?</span>
            {[1,2,3,4,5].map(n=> <button key={n} onClick={()=>setRating(n)} className="btn" style={{background: rating===n?'#ff7a1a':'#e5e7eb', color: rating===n?'#fff':'#111'}}>{n}</button>)}
          </div>
          <div style={{textAlign:'right',marginTop:12}}><button className="btn" onClick={complete}>Save progress</button></div>
        </div>
      </div>
      <aside className="card"><b>Tips</b><ul>{(tips||[]).map((t,i)=><li key={i} className="hint" style={{margin:'6px 0'}}>{t}</li>)}</ul></aside>
    </div>)}
  </Layout>)
}
