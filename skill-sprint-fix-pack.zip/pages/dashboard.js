import { useEffect, useState } from 'react'
import Layout from '../components/Layout'
import { storage } from '../lib/storage'
import Link from 'next/link'

export default function Dashboard(){
  const [profile,setProfile]=useState(null)
  const [history,setHistory]=useState([])
  const [streak,setStreak]=useState(0)

  useEffect(()=>{
    const p=storage.get('ss_profile'); setProfile(p)
    const h=storage.get('ss_history',[]); setHistory(h)
    const days = new Set(h.map(e=> new Date(e.date).toDateString()))
    let s=0; let t=new Date(); while(days.has(t.toDateString())){s++; t.setDate(t.getDate()-1)}; setStreak(s)
  },[])

  return (<Layout active="dashboard">
    <h1>Dashboard</h1>
    {!profile && <div className="card"><b>No profile yet</b><p className="hint">Take the skill test to personalise your plan.</p><Link className="btn" href="/onboarding">Start Skill Test</Link></div>}
    {profile && (<>
      <div className="card"><b>Profile</b><p className="hint">Role: {profile.role} • Years: {profile.years} • Focus: {(profile.focus||[]).join(', ')||'—'} • Time: {profile.time} min/day</p><p className="hint">Challenge: {profile.challenge||'—'}</p><Link className="btn" href="/sprint">Go to today&apos;s sprint</Link></div>
      <div className="card"><b>Progress</b><p className="hint">Streak: {streak} day(s) • Completed sprints: {history.length}</p><ul>{history.slice().reverse().map((e,i)=>(<li key={i}><b>{e.title||'Sprint'}</b> — {new Date(e.date).toLocaleDateString()} — rating: {e.rating||'—'}</li>))}</ul></div>
    </>)}
  </Layout>)
}
