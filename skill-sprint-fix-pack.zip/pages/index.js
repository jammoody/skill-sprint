import Head from 'next/head'
import Link from 'next/link'
import Layout from '../components/Layout'
export default function Home(){
  return (<Layout active="home">
    <Head><title>Skill Sprint</title></Head>
    <section className="grid grid-2" style={{alignItems:'center'}}>
      <div>
        <h1 style={{fontSize:38,margin:'8px 0'}}>Your Daily Workout for Business Growth</h1>
        <p className="hint">Short, sharp, daily sprints that turn learning into results.</p>
        <div style={{display:'flex',gap:12,marginTop:12}}>
          <Link href="/onboarding" className="btn">Take My Free Skill Test</Link>
          <Link href="/sprint" className="btn" style={{background:'#111827'}}>Try a Sprint</Link>
        </div>
      </div>
      <div className="card">
        <b>Preview: Day 1</b>
        <p className="hint">Write a one-sentence value proposition. We'll refine it tomorrow.</p>
        <textarea rows="4" style={{width:'100%'}} placeholder="We help [who] achieve [outcome] by [how]." />
      </div>
    </section>
  </Layout>)
}
