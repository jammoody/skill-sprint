# Skill Sprint — Branded MVP (Chromebook Steps)

This folder is ready to upload directly to GitHub and deploy on Vercel.

## 1) Upload to GitHub
1. Go to your `skill-sprint` repo.
2. Click **Add file → Upload files**.
3. Drag **all files & folders in this folder** (not the folder itself) into GitHub.
4. Click **Commit changes**.

You should see at the repo root:
- `package.json`, `next.config.js`
- `pages/`, `components/`, `lib/`, `styles/`
- `README_CHROMEBOOK.md`

## 2) Deploy on Vercel
- If the project is already linked: **Deployments → Redeploy**.
- If not linked yet: **Add New Project → Import Git Repository** → select `skill-sprint` → Deploy.

No environment variables required for this mock API version.

## 3) Test pages
- `/` (homepage with test links)
- `/onboarding`
- `/sprint`
- `/dashboard`

## 4) Optional: enable OpenAI later
- Replace `pages/api/generate-sprint.js` with the AI version and add `OPENAI_API_KEY` in Vercel env vars.
