import Head from 'next/head'
import Link from 'next/link'
import Layout from '../components/Layout'
export default function Home(){
  return (
    <Layout active="home">
      <Head><title>Skill Sprint — Your Daily Business Workout</title></Head>
      <section className="hero">
        <div className="container section grid grid-2" style={{alignItems:'center'}}>
          <div>
            <div className="kicker">Built for busy founders & teams</div>
            <h1 className="h1">Short, sharp training.<br/>Long‑term results.</h1>
            <p className="sub">Pick your focus — marketing, e‑commerce, retail, leadership — and Skill Sprint delivers a 5–10 minute daily workout that turns learning into action.</p>
            <div style={{display:'flex',gap:12,marginTop:16}}>
              <Link href="/onboarding" className="btn">Take My Free Skill Test</Link>
              <Link href="/sprint" className="btn secondary">Try Today’s Sprint</Link>
            </div>
            <div className="testlinks" style={{marginTop:18}}>
              <span className="hint">Test pages: </span>
              <Link href="/">Home</Link> · <Link href="/onboarding">Onboarding</Link> · <Link href="/sprint">Sprint</Link> · <Link href="/dashboard">Dashboard</Link>
            </div>
          </div>
          <div className="card">
            <div className="badge">Preview</div>
            <h3>Day 1: Value Proposition</h3>
            <p className="hint">Write a one‑sentence value proposition. We’ll refine it tomorrow.</p>
            <textarea rows="4" style={{width:'100%',background:'#0b1020',border:'1px solid #1f2a44',color:'#e5e7eb',borderRadius:10,padding:12}} placeholder="We help [who] achieve [outcome] by [how]." />
            <div style={{textAlign:'right',marginTop:8}}><button className="btn">Save</button></div>
          </div>
        </div>
      </section>
      <section>
        <div className="container section">
          <div className="kicker">Why it works</div>
          <div className="grid" style={{gridTemplateColumns:'repeat(3,1fr)'}}>
            <div className="card feature">
              <div className="badge">1</div>
              <div><b>Daily momentum</b><p className="hint">5–10 minutes a day beats binge‑learning. Build the habit, see compounding gains.</p></div>
            </div>
            <div className="card feature">
              <div className="badge">2</div>
              <div><b>Action first</b><p className="hint">Every sprint ends with a real task to move your business forward today.</p></div>
            </div>
            <div className="card feature">
              <div className="badge">3</div>
              <div><b>Adapts to you</b><p className="hint">Your plan evolves based on results and feedback — like a coach who learns your style.</p></div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div className="container section grid grid-2" style={{alignItems:'start'}}>
          <div className="card">
            <div className="kicker">What you’ll achieve</div>
            <ul className="hint" style={{lineHeight:'1.9'}}>
              <li>Sharper positioning & value proposition</li>
              <li>Better conversion with quick CRO wins</li>
              <li>Clearer marketing priorities and metrics</li>
              <li>Stronger leadership rhythms & reviews</li>
            </ul>
          </div>
          <div className="card">
            <div className="kicker">Perfect for</div>
            <ul className="hint" style={{lineHeight:'1.9'}}>
              <li>Owners & managers who are time‑poor</li>
              <li>Teams who want a lightweight training habit</li>
              <li>Anyone who learns best by doing</li>
            </ul>
          </div>
        </div>
      </section>
    </Layout>
  )
}
